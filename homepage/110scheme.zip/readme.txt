              *----====----====----====----====----*
                Roland Boss DR-110 Dr Rhythm Graphic
                      SERVICE MANUAL DOCUMENTS      
              <------------------------------------>
              From the DR-110 Information Homepage @
				http://theninhotline.net/dr110

                Filenames are rather self explanitory.
      I don't know much about electronics, so if you want to
      fill me in on charitable measure, it's leviathant@gmail.com
                                 Enjoy!
+---------------------------------------------------------------+
| disassembl.gif - Disassembly instructions. Start here ;)      |
| cpuboard.gif - Picture of the CPU board.      				|
| cpuschem.gif - CPU Board Schematics.  						|
| vbscheme.gif - Voicing board schematics. 						|
| waveform.gif - Tells the osc/trigger waveforms.				|
| voicing.gif - Details on sound generators and such. 			|
| circuits.gif - Pin functions for the DR-110's IC.				|
| switchmatrix.gif - Switch matrix.  Clock stuff and the like.	|
+---------------------------------------------------------------+

Since you've taken the time to read this, I'd much appreciate it
that if you do some kind of nifty (or even minimal) modification
to the DR-110, please email me and let me know what you've done,
and if you'd be so kind to provide schemes and/or instructions as
a sort of 'thanks for letting me have the DR-110 schemes Matt'
kind of gesture.  Please send em to leviathant@gmail.com and let me
know if you would mind if I posted them publicly on the same web
site that these schemes are available from.  Enjoy, happy modding!

Oh, here's the parts list, painstakingly hand typed by myself.

IC_____________________-
15179122	HD44790a44P	2k x 4bit CMOS CPU with LCD driver
15179305	(mu)PD444C	1k x 4bit static RAM
15159140h0	HD14006BP	18-bit static shift register
15159104h0	HD14011BP	quadruple 2-input NAND gate
15159116TO	TC4069UBP	Hex inverter
15159117H0	HD14070bp	quadruple exclusive-OR gate
15189102	NJM4558DD	OP amp (pcb 2291084302-UP)
15199521	M51501L	Power amp (pcb 2291084302-UP)
15199517	LM-386N-1	Power amp (pcb up to 2291084300)

TRANSISTOR_________________-
15119125	2SA1115-F
15119602	2SB647-C
15119607	2SB642-R
15129137	2SC2603-F
15129145	2SC945-K (or 2SC1815-BL)

DIODE___________________
15019125	1ss-133
15019530	s5500g
15129137	RD6.8eb-2	zener
15019138	DAN 201	diode array
15019139	DAP 201	diode array